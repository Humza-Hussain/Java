// src/main/java/com/example/demo/dto/InventoryDTO.java
package com.example.demo.dto;

public class InventoryDTO {
    private Long productId;
    private Integer stock;

    // Getters and Setters
    public Long getProductId() {
        return productId;
    }

    public void setProductId(Long productId) {
        this.productId = productId;
    }

    public Integer getStock() {
        return stock;
    }

    public void setStock(Integer stock) {
        this.stock = stock;
    }
}