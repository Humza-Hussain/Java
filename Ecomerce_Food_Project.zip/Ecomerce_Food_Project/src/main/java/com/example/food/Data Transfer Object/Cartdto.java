// src/main/java/com/example/demo/dto/CartDTO.java
package com.example.demo.dto;

import java.util.List;

public class CartDTO {
    private Long cartId;
    private Long userId;
    private List<CartItemDTO> items;

    // Getters and Setters
    public Long getCartId() {
        return cartId;
    }

    public void setCartId(Long cartId) {
        this.cartId = cartId;
    }

    public Long getUser Id() {
        return userId;
    }

    public void setUser Id(Long userId) {
        this.userId = userId;
    }

    public List<CartItemDTO> getItems() {
        return items;
    }

    public void setItems(List<CartItemDTO> items) {
        this.items = items;
    }
}