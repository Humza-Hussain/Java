package com.example.orders.dto;

import java.util.List;

public class OrderDTO {
    private String referenceId;
    private int numberOfOrders;
    private List<String> orderDetails;

    // Getters and Setters
    public String getReferenceId() {
        return referenceId;
    }

    public void setReferenceId(String referenceId) {
        this.referenceId = referenceId;
    }

    public int getNumberOfOrders() {
        return numberOfOrders;
    }

    public void setNumberOfOrders(int numberOfOrders) {
        this.numberOfOrders = numberOfOrders;
    }

    public List<String> getOrderDetails() {
        return orderDetails;
    }

    public void setOrderDetails(List<String> orderDetails) {
        this.orderDetails = orderDetails;
    }
}