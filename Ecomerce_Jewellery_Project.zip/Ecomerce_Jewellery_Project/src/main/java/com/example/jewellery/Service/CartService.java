import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class CartService {

    @Autowired
    private CartRepository cartRepository;

    public Cart createCart(Cart cart) {
        return cartRepository.save(cart);
    }

    public Cart getCartByUser Id(Long userId) {
        return cartRepository.findByUser Id(userId);
    }

    public Cart updateCart(Long userId, Cart cart) {
        // Logic to update cart
        return cartRepository.save(cart);
    }

    public void deleteCart(Long userId) {
        cartRepository.deleteByUser Id(userId);
    }
}