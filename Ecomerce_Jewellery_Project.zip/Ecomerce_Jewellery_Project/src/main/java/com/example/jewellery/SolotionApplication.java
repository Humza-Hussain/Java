package com.example.solotion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SolotionApplication {

	public static void main(String[] args) {
		SpringApplication.run(SolotionApplication.class, args);
	}

}

  