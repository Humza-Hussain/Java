package com.example.demo.exception;

public class CartItemException extends RuntimeException {
    public CartItemException(String message) {
        super(message);
    }
}