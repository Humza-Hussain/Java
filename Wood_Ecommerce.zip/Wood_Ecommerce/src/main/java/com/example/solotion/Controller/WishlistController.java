import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/wishlists")
public class WishlistController {

    @Autowired
    private WishlistService wishlistService;

    @PostMapping
    public ResponseEntity<Wishlist> createWishlist(@RequestBody Wishlist wishlist) {
        Wishlist createdWishlist = wishlistService.createWishlist(wishlist);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdWishlist);
    }

    @GetMapping("/{userId}")
    public ResponseEntity<Wishlist> getWishlistByUser Id(@PathVariable Long userId) {
        Wishlist wishlist = wishlistService.getWishlistByUser Id(userId);
        return wishlist != null ? ResponseEntity.ok(wishlist) : ResponseEntity.status(HttpStatus.NOT_FOUND).build();
    }

    @PutMapping("/{userId}")
    public ResponseEntity<Wishlist> updateWishlist(@PathVariable Long userId, @RequestBody Wishlist wishlist) {
        Wishlist updatedWishlist = wishlistService.updateWishlist(userId, wishlist);
        return updatedWishlist != null ? ResponseEntity.ok(updatedWishlist) : ResponseEntity.status(HttpStatus.NOT_FOUND).build();
    }

    @DeleteMapping("/{userId}")
    public ResponseEntity<Void> deleteWishlist(@PathVariable Long userId) {
        boolean isDeleted = wishlistService.deleteWishlist(userId);
        return isDeleted ? ResponseEntity.noContent().build() : ResponseEntity.status(HttpStatus.NOT_FOUND).build();
    }
}