package com.example.demo.exception;

public class CartException extends RuntimeException {
    public CartException(String message) {
        super(message);
    }
}