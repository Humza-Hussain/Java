// src/main/java/com/example/demo/dto/WishlistDTO.java
package com.example.demo.dto;

import java.util.List;

public class WishlistDTO {
    private Long wishlistId;
    private Long userId;
    private List<Long> productIds;

    // Getters and Setters
    public Long getWishlistId() {
        return wishlistId;
    }

    public void setWishlistId(Long wishlistId) {
        this.wishlistId = wishlistId;
    }

    public Long getUser Id() {
        return userId;
    }

    public void setUser Id(Long userId) {
        this.userId = userId;
    }

    public List<Long> getProductIds() {
        return productIds;
    }

    public void setProductIds(List<Long> productIds) {
        this.productIds = productIds;
    }
}