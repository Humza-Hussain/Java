import javax.persistence.*;
@Entity
@Table(name = "item_carts")
public class ItemCart {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private double price;
    private String description;
    private int stock;

    // Getters and Setters
}
