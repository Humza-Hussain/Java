package com.example.demo.exception;

public class DiscountException extends RuntimeException {
    public DiscountException(String message) {
        super(message);
    }
}