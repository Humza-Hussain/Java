import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository; // Assuming you have a UserRepository interface

    // Create a new user
    public User createUser (User user) {
        // You might want to add password hashing or other business logic here
        return userRepository.save(user);
    }

    // Get a user by ID
    public User getUser ById(Long id) {
        return userRepository.findById(id).orElse(null);
    }

    // Get all users
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    // Update a user
    public User updateUser (Long id, User user) {
        if (userRepository.existsById(id)) {
            user.setId(id); // Assuming you have a setId method in User
            return userRepository.save(user);
        }
        return null; // Or throw an exception
    }

    // Delete a user
    public boolean deleteUser (Long id) {
        if (userRepository.existsById(id)) {
            userRepository.deleteById(id);
            return true;
        }
        return false; // Or throw an exception
    }
}