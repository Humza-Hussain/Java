package com.example.demo.exception;

public class OrdersException extends RuntimeException {
    public OrdersException(String message) {
        super(message);
    }
}