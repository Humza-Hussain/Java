package com.example.solotion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SolotionApplicationTests {

	@Test
	void contextLoads() {
	}

}
