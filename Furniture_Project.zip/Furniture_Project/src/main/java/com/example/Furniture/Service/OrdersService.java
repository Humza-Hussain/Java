package com.example.orders.service;

import com.example.orders.dto.OrderDTO;
import com.example.orders.model.Order;
import com.example.orders.repository.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OrderService {

    @Autowired
    private OrderRepository orderRepository;

    public Order createOrder(OrderDTO orderDTO) {
        Order order = new Order();
        order.setReferenceId(orderDTO.getReferenceId());
        order.setNumberOfOrders(orderDTO.getNumberOfOrders());
        order.setOrderDetails(orderDTO.getOrderDetails());
        return orderRepository.save(order);
    }

    public Order getOrderByReferenceId(String referenceId) {
        return orderRepository.findByReferenceId(referenceId);
    }

    public List<Order> getAllOrders() {
        return orderRepository.findAll();
    }
}