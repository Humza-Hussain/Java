import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CartItemsService {

    @Autowired
    private CartItemsRepository cartItemsRepository;

    public CartItem addCartItem(CartItem cartItem) {
        return cartItemsRepository.save(cartItem);
    }

    public List<CartItem> getCartItemsByCartId(Long cartId) {
        return cartItemsRepository.findByCartId(cartId);
    }

    public void deleteCartItem(Long id) {
        cartItemsRepository.deleteById(id);
    }
}