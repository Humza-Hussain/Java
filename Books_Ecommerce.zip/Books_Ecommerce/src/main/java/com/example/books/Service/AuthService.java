import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AuthService {

    @Autowired
    private UserRepository userRepository; // Assuming you have a UserRepository

    public User register(User user) {
        // Logic for user registration
        return userRepository.save(user);
    }

    public User login(String email, String password) {
        // Logic for user authentication
        return userRepository.findByEmailAndPassword(email, password);
    }
}