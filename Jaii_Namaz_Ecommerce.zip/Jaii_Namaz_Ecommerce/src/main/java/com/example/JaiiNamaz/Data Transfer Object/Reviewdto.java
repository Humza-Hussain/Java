// src/main/java/com/example/demo/dto/ReviewDTO.java
package com.example.demo.dto;

public class ReviewDTO {
    private Long reviewId;
    private Long productId;
    private Long userId;
    private String comment;
    private Integer rating;

    // Getters and Setters
    public Long getReviewId() {
        return reviewId;
    }

    public void setReviewId(Long reviewId) {
        this.reviewId = reviewId;
    }

    public Long getProductId() {
        return productId;
    }

    public void setProductId(Long productId) {
        this.productId = productId;
    }

    public Long getUser Id() {
        return userId;
    }

    public void setUser Id(Long userId) {
        this.userId = userId;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public Integer getRating() {
        return rating;
    }

    public void setRating(Integer rating) {
        this.rating = rating;
    }
}