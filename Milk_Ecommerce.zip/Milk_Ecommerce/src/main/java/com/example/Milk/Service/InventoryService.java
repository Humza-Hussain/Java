import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class InventoryService {

    @Autowired
    private InventoryRepository inventoryRepository;

    public Inventory addInventory(Inventory inventory) {
        return inventoryRepository.save(inventory);
    }

    public Inventory getInventoryByProductId(Long productId) {
        return inventoryRepository.findByProductId(productId);
    }

    public void updateInventory(Long productId, Inventory inventory) {
        inventory.setProductId(productId);
        inventoryRepository.save(inventory);
    }

    public void deleteInventory(Long productId) {
        inventoryRepository.deleteByProductId(productId);
    }
}