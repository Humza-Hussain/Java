package com.example.demo.exception;

public class ReviewException extends RuntimeException {
    public ReviewException(String message) {
        super(message);
    }
}