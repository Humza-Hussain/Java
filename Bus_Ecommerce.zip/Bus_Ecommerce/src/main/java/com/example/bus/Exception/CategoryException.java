package com.example.demo.exception;

public class CategoryException extends RuntimeException {
    public CategoryException(String message) {
        super(message);
    }
}